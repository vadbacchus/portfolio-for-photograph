export function getAttr(el, attr) {
  return el.getAttribute(attr);
}