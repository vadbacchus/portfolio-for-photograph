export function isVisible(el) {
  return el.offsetWidth > 0 && el.offsetHeight > 0;
}